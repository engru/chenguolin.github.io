// Package config unit test
// Created by chenguolin 2018-11-16
package config

import (
	"fmt"
	"os"
	"testing"

	"github.com/gin-gonic/gin/json"
)

func TestLoadFrom(t *testing.T) {
	// load api conf
	// TODO (@cgl) 路径需要用户自行修改
	conf, err := loadFrom(os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml")
	if err != nil {
		fmt.Println(err)
		t.Fatal("TestLoadFrom loadFrom err != nil")
	}
	if conf == nil {
		t.Fatal("TestLoadFrom loadFrom api conf == nil")
	}

	bytes, err := json.Marshal(conf)
	if err != nil {
		t.Fatal("TestLoadFrom err != nil")
	}
	fmt.Println(string(bytes))
}

func TestGetConfig(t *testing.T) {
	// case 1
	filePath := ""
	conf, err := GetConfig(filePath)
	if err == nil {
		t.Fatal("TestGetConfig case 1 GetConfig err == nil")
	}
	if conf != nil {
		t.Fatal("TestGetConfig case 1 GetConfig apiConf != nil")
	}

	// case 2
	// TODO (@cgl) 用户需要自行修改路径
	filePath = os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	SetConfig(nil)
	conf, err = GetConfig(filePath)
	if err != nil {
		fmt.Println(err)
		t.Fatal("TestGetConfig case 2 GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetConfig case 2 GetConfig conf == nil")
	}

	// deploy
	if conf.Deploy == nil {
		t.Fatal("apiConf.Deploy is nil")
	}
	// mysql
	if conf.Mysql == nil {
		t.Fatal("apiConf.Mysql is nil")
	}
	// redis
	if conf.Redis == nil {
		t.Fatal("apiConf.Redis is nil")
	}
	// memcache
	if conf.Mc == nil {
		t.Fatal("apiConf.Mc is nil")
	}
	// kafka
	if conf.Kafka == nil {
		t.Fatal("apiConf.Kafka is nil")
	}

	bytes, err := json.Marshal(conf)
	if err != nil {
		t.Fatal("json Marshal conf error")
	}
	fmt.Println(string(bytes))
}

func TestGetDeployConf(t *testing.T) {
	// TODO (@cgl) 用户需要自行修改路径
	SetConfig(nil)
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := GetConfig(filePath)
	if err != nil {
		fmt.Println(err)
		t.Fatal("TestGetDeployConf GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetDeployConf GetConfig conf == nil")
	}

	deploy := GetDeployConf()
	if deploy == nil {
		t.Fatal("TestGetDeployConf GetDeployConf == nil")
	}
	fmt.Println(deploy)
}

func TestGetMysqlConf(t *testing.T) {
	// TODO (@cgl) 用户需要自行修改路径
	SetConfig(nil)
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := GetConfig(filePath)
	if err != nil {
		t.Fatal("TestGetMysqlConf GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetMysqlConf GetConfig conf == nil")
	}

	mysql := GetMysqlConf()
	if mysql == nil {
		t.Fatal("TestGetMysqlConf GetMysqlConf == nil")
	}
}

func TestGetRedisConf(t *testing.T) {
	// TODO (@cgl) 用户需要自行修改路径
	SetConfig(nil)
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := GetConfig(filePath)
	if err != nil {
		t.Fatal("TestGetRedisConf GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetRedisConf GetConfig conf == nil")
	}

	redis := GetRedisConf()
	if redis == nil {
		t.Fatal("TestGetRedisConf GetRedisConf == nil")
	}
}

func TestGetMemcacheConf(t *testing.T) {
	// TODO (@cgl) 用户需要自行修改路径
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := GetConfig(filePath)
	if err != nil {
		t.Fatal("TestGetMemcacheConf GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetMemcacheConf GetConfig conf == nil")
	}

	mc := GetMcConf()
	if mc == nil {
		t.Fatal("TestGetMemcacheConf GetMcConf mc == nil")
	}
}

func TestGetKafkaConf(t *testing.T) {
	// TODO (@cgl) 用户需要自行修改路径
	SetConfig(nil)
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := GetConfig(filePath)
	if err != nil {
		t.Fatal("TestGetKafkaConf GetConfig err != nil")
	}
	if conf == nil {
		t.Fatal("TestGetKafkaConf GetConfig conf == nil")
	}

	kafka := GetKafkaConf()
	if kafka == nil {
		t.Fatal("TestGetKafkaConf GetKafkaConf kafka == nil")
	}
}
