// Package controller default middleware
// Created by chenguolin 2018-11-16
package main

import (
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/chenguolin/go-api-service/pkg/request"
	"github.com/chenguolin/go-common/http"
	"github.com/chenguolin/go-common/logger"
	"github.com/chenguolin/go-common/trace"
	"github.com/chenguolin/go-common/ulid"
	"github.com/chenguolin/go-log/log"
	"github.com/gin-gonic/gin"
)

// SetRequestID set request id
func SetRequestID() gin.HandlerFunc {
	return func(c *gin.Context) {
		// set request id
		reqID := ulid.NewUlid()
		c.Set(request.RequestIDKey, reqID)
		// print start log
		logger.Info(trace.WithTraceID(reqID), "[SetRequestID] Start process request ...",
			log.Object("requestParams", c.Request.Form),
			log.Object("startTime", time.Now().Unix()),
			log.Object("requestURI", c.Request.URL.Path))
		// next handler
		c.Next()
	}
}

// SetCommonParams set common params
func SetCommonParams() gin.HandlerFunc {
	return func(c *gin.Context) {
		// TODO (@cgl) 业务逻辑 一般会包括以下几点
		// 1. 特殊url过滤
		// 2. 公共参数校验
		// 3. 通用参数设置

		// 下一个handler
		c.Next()
	}
}

// CheckSignature check http signature
// Signature header format:
//    `Signature: sigTime={sigTime}&signature={signature}`
// variables:
// - sigTime = unix timestamp example 1547890889
// - signature = signature string
func CheckSignature() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 1. get signature header
		sigHeader := c.GetHeader("Signature")
		fields := strings.Split(sigHeader, "&")
		// check fields
		if fields == nil || len(fields) <= 2 {
			errLog := string("[CheckSignature] Signature header invalid ~")
			request.APIError(c, errLog)
			return
		}

		// 2. parse fields as query
		params, err := url.ParseQuery(sigHeader)
		if err != nil {
			errLog := string("[CheckSignature] Signature header parse error: ") + err.Error()
			request.APIError(c, errLog)
			return
		}

		// 3. check sigTime
		sigTimeStr := params.Get("sigTime")
		sigTime, err := strconv.ParseInt(sigTimeStr, 10, 64)
		if err != nil {
			errLog := string("[CheckSignature] Signature sigTimeStr ParseInt error: ") + err.Error()
			request.APIError(c, errLog)
			return
		}
		if sigTime <= time.Now().Unix() {
			errLog := string("[CheckSignature] Signature sigTime expired ~")
			request.APIError(c, errLog)
			return
		}
		// set sigTime
		c.Set("sigTime", sigTimeStr)

		// 4. check signature
		signature := params.Get("signature")
		if signature != http.GenSignature(c) {
			errLog := string("[CheckSignature] Signature check failed ~")
			request.APIError(c, errLog)
			return
		}

		// 下一个handler
		c.Next()
	}
}

// CheckAuthorization check http authorization
// Authorization header format:
//    `Authorization: pubk={pubk}&sigTime={sigTime}&signature={signature}`
// variables:
// - pubk = public key
// - sigTime = unix timestamp example 1547890889
// - signature = signature string
func CheckAuthorization() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 1. get signature header
		authHeader := c.GetHeader("Authorization")
		fields := strings.Split(authHeader, "&")
		// check fields
		if fields == nil || len(fields) <= 2 {
			errLog := string("[CheckAuthorization] Authorization header invalid ~")
			request.APIError(c, errLog)
			return
		}

		// 2. parse fields as query
		params, err := url.ParseQuery(authHeader)
		if err != nil {
			errLog := string("[CheckAuthorization] Authorization header parse error: ") + err.Error()
			request.APIError(c, errLog)
			return
		}

		// 3. check sigTime
		sigTimeStr := params.Get("sigTime")
		sigTime, err := strconv.ParseInt(sigTimeStr, 10, 64)
		if err != nil {
			errLog := string("[CheckAuthorization] Authorization sigTimeStr ParseInt error: ") + err.Error()
			request.APIError(c, errLog)
			return
		}
		if sigTime <= time.Now().Unix() {
			errLog := string("[CheckAuthorization] Authorization sigTime expired ~")
			request.APIError(c, errLog)
			return
		}

		// 4. get public key and signature
		pubk := params.Get("pubk")
		sig := params.Get("signature")

		// 4. check authrization
		c.Set("publicKey", pubk)
		c.Set("signature", sig)
		c.Set("sigTime", sigTimeStr)

		// 下一个handler
		c.Next()
	}
}
