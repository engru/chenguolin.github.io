// Package user delete user api
// Created by chenguolin 2018-11-16
package user

import (
	"github.com/chenguolin/go-api-service/pkg/request"
	"github.com/chenguolin/go-api-service/pkg/user"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

// DeleteUserRequest request
type DeleteUserRequest struct {
	UID int64 `json:"uid"   form:"uid"   binding:"required"`
}

// DeleteUserResponse response
type DeleteUserResponse struct {
}

// DeleteUser for delete user
func DeleteUser(c *gin.Context) {
	// 1. bind request params
	req := new(DeleteUserRequest)
	err := c.ShouldBindWith(req, binding.Default(c.Request.Method, c.ContentType()))
	if err != nil {
		errLog := "[DeleteUser] DeleteUserRequest fields ShouldBindWith check error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 2. call UserService DeleteUser
	userService := user.GetUserService()
	err = userService.DeleteUser(req.UID)
	if err != nil {
		errLog := "[DeleteUser] UserService delete user error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 3. response
	response := &DeleteUserResponse{}
	request.APISuccess(c, response)
}
