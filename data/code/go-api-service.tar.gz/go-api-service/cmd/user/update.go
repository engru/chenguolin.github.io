// Package user update user api
// Created by chenguolin 2018-11-16
package user

import (
	"github.com/chenguolin/go-api-service/pkg/request"
	"github.com/chenguolin/go-api-service/pkg/user"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

// UpdateUserRequest request
type UpdateUserRequest struct {
	UID      int64  `json:"uid"       form:"uid"       binding:"required"`
	NewName  string `json:"new_name"  form:"new_name"  binding:"required"`
	NewPhone string `json:"new_phone" form:"new_phone" binding:"required"`
}

// UpdateUserResponse response
type UpdateUserResponse struct {
}

// UpdateUser for update user info
func UpdateUser(c *gin.Context) {
	// 1. bind request params
	req := new(UpdateUserRequest)
	err := c.ShouldBindWith(req, binding.Default(c.Request.Method, c.ContentType()))
	if err != nil {
		errLog := "[UpdateUser] UpdateUserRequest fields ShouldBindWith check error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 2. call UserService UpdateUser
	userService := user.GetUserService()
	err = userService.UpdateUser(req.UID, req.NewName, req.NewPhone)
	if err != nil {
		errLog := "[UpdateUser] UserService update user info error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 3. response
	response := &UpdateUserResponse{}
	request.APISuccess(c, response)
}
