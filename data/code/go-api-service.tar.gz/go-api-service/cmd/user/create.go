// Package user create user api
// Created by chenguolin 2018-11-16
package user

import (
	"github.com/chenguolin/go-api-service/pkg/request"
	"github.com/chenguolin/go-api-service/pkg/user"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

// CreateUserRequest request
type CreateUserRequest struct {
	UID   int64  `json:"uid"   form:"uid"   binding:"required"`
	Name  string `json:"name"  form:"name"  binding:"required"`
	Phone string `json:"phone" form:"phone" binding:"required"`
}

// CreateUserResponse response
type CreateUserResponse struct {
}

// CreateUser for new user
func CreateUser(c *gin.Context) {
	// 1. bind request params
	req := new(CreateUserRequest)
	err := c.ShouldBindWith(req, binding.Default(c.Request.Method, c.ContentType()))
	if err != nil {
		errLog := "[CreateUser] CreateUserRequest fields ShouldBindWith check error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 2. call UserService AddUser
	userService := user.GetUserService()
	args := &user.AddUserArgs{
		UID:   req.UID,
		Name:  req.Name,
		Phone: req.Phone,
	}

	err = userService.AddUser(args)
	if err != nil {
		errLog := "[CreateUser] UserService add user error: " + err.Error()
		request.APIError(c, errLog)
		return
	}

	// 3. response
	response := &CreateUserResponse{}
	request.APISuccess(c, response)
}
