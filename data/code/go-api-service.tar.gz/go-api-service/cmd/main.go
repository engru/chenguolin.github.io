// Package main entry point
// Created by chenguolin 2018-11-18
package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"runtime/debug"
	"syscall"
	"time"

	"github.com/chenguolin/go-api-service/config"
	"github.com/chenguolin/go-api-service/pkg/instance"
	"github.com/chenguolin/go-healthcheck/healthcheck"
	"github.com/chenguolin/go-log/log"
	"github.com/gin-gonic/gin"
)

var (
	httpServer *http.Server
)

func main() {
	log.Info("Start go-api-service ...")

	// 1. get ENV CLUSTER_STAGE value
	clusterStage := os.Getenv("CLUSTER_STAGE")
	if clusterStage == "" {
		panic("os.Getenv get CLUSTER_STAGE value is empty")
	}

	// 2. load config file
	configFile := fmt.Sprintf("./%s-config.toml", clusterStage)
	conf, err := config.GetConfig(configFile)
	if err != nil {
		panic("config.GetConfig error: " + err.Error())
	}

	// 3. init application context
	err = instance.AppInit(conf)
	if err != nil {
		panic("instance.AppInit error: " + err.Error())
	}

	// 4. start HTTP Server
	log.Info("Start HTTP Server listening on: " + conf.Deploy.APIAddr)

	httpServer = &http.Server{
		Addr: conf.Deploy.APIAddr,
	}

	// start HTTP Server
	startHTTPServer()

	// block until receive signal
	shutdown := make(chan struct{})
	registerSignal(shutdown)
	<-shutdown

	// shutdown HTTP server
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	err = httpServer.Shutdown(ctx)
	if err != nil {
		panic("httpServer.Shutdown error: " + err.Error())
	}
	log.Info("Shutdown HTTP Server successful ~")

	log.Info("Shutdown go-api-service ~")
}

// startHTTPServer start HTTP Server
func startHTTPServer() {
	// new gin engine
	// set release mode
	gin.SetMode(gin.ReleaseMode)
	engine := gin.New()

	// set gin global middleware handler
	// 1. recovery handler default write 2 os.stderr
	// 2. log handler write http access log
	engine.Use(gin.Recovery())
	engine.Use(log.AccessLogFunc(log.GetLogger()))

	// register health and PProf
	healthcheck.RegisterHealthCheck(engine)

	// set Router
	SetupRoute(engine)

	// start HTTP Server
	httpServer.Handler = engine
	go func() {
		err := httpServer.ListenAndServe()
		if err != nil {
			panic("[startHTTPServer] httpServer.ListenAndServe error: " + err.Error())
		}
	}()
}

// registerSignal register shutdown signal
func registerSignal(shutdown chan struct{}) {
	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		defer func() {
			if err := recover(); err != nil {
				log.Error("[registerSignal] panic error: ", log.Object("error", err))
				debug.PrintStack()
			}
		}()

		for sig := range c {
			close(shutdown)
			log.Info("[registerSignal] got system signal:" + sig.String() + ", going to shutdown ...")
			break
		}
	}()
}
