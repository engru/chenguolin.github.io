// Package user service
// Created by chenguolin 2018-11-17
package user

import (
	"github.com/chenguolin/go-api-service/pkg/instance"
)

var (
	service *Service
)

// GetUserService get UserService
func GetUserService() *Service {
	return service
}

func init() {
	instance.AddInitFunc("UserService", func() {
		uRepo := newRepo(instance.GetMysqlClient())
		service = NewUserService(uRepo)
	})
}
