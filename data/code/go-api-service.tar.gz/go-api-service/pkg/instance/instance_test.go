// Package instance unit test
// Created by chenguolin 2018-11-16
package instance

import (
	"fmt"
	"os"
	"testing"

	"github.com/chenguolin/go-api-service/config"
	"github.com/chenguolin/go-log/log"
)

// AppInitTest test init application
func AppInitTest() {
	// TODO (@cgl) 用户需要自行修改本地配置文件路径
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/config/conf/pre-config.toml"
	conf, err := config.GetConfig(filePath)
	if err != nil {
		log.Error("AppInitTest config.GetConfig error", log.Err(err))
	}

	err = AppInit(conf)
	if err != nil {
		log.Error("AppInitTest AppInit err != nil")
	}
}

func TestInitAppContext(t *testing.T) {
	config.SetConfig(nil)
	// TODO (@cgl) 用户需要自行修改路径
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	cfg, err := config.GetConfig(filePath)
	if err != nil {
		fmt.Println(err)
		t.Fatal("TestInitAppContext config.GetConfig err != nil")
	}

	err = AppInit(cfg)
	if err != nil {
		t.Fatal("TestInitAppContext AppInit err != nil")
	}
}

func TestInitTestContext(t *testing.T) {
	AppInitTest()
}

func TestAddInitFunc(t *testing.T) {
	f := func() { fmt.Println("hello word func1") }
	AddInitFunc("func", f)

	f2 := func() { fmt.Println("hello word func2") }
	AddInitFunc("func2", f2)

	// TODO (@cgl) 用户需要自行修改路径
	config.SetConfig(nil)
	filePath := os.Getenv("GOPATH") + "/src/github.com/chenguolin/go-api-service/build/conf/pre-config.toml"
	conf, err := config.GetConfig(filePath)
	if err != nil {
		t.Fatal("TestAddInitFunc config.GetConfig err != nil")
	}

	err = AppInit(conf)
	if err != nil {
		t.Fatal("TestAddInitFunc AppInit err != nil")
	}
}

func TestGetMysqlClient(t *testing.T) {
	// TODO (@cgl)
}

func TestGetRedisClient(t *testing.T) {
	// TODO (@cgl)
}

func TestGetMcClient(t *testing.T) {
	// TODO (@cgl)
}

func TestGetKafkaConf(t *testing.T) {
	// TODO (@cgl)
}
