// Package instance global instance
// Created by chenguolin 2018-11-16
package instance

import (
	"fmt"

	"github.com/bradfitz/gomemcache/memcache"
	"github.com/chenguolin/go-api-service/config"
	"github.com/chenguolin/go-log/log"
	"github.com/chenguolin/go-mysql/mysql"
	"github.com/go-redis/redis"
)

var (
	mysqlClient *mysql.Mysql
	redisClient *redis.ClusterClient
	mcClient    *memcache.Client
	kafkaConf   *config.KafkaConf
)

// PkgInitFunc pkg init function
type PkgInitFunc func()

// pkgInitFuncs all init functions
var pkgInitFuncs = make(map[string]PkgInitFunc)

// AddInitFunc add InitFunc 2 pkgInitFuncs
// same name InitFunc will be override
func AddInitFunc(name string, f PkgInitFunc) {
	pkgInitFuncs[name] = f
}

// AppInit init application
func AppInit(conf *config.Config) error {
	var err error

	// new mysql client
	mysqlClient, err = newMysqlClient(conf.Mysql)
	if err != nil {
		return fmt.Errorf("newMysqlClient error: %s", err.Error())
	}

	// new redis client
	redisClient, err = newRedisClient(conf.Redis)
	if err != nil {
		return fmt.Errorf("newRedisClient error: %s", err.Error())
	}

	// new mc client
	mcClient, err = newMcClient(conf.Mc)
	if err != nil {
		return fmt.Errorf("newMcClient error: %s", err.Error())
	}

	kafkaConf = conf.Kafka

	// execute Init func
	for name, f := range pkgInitFuncs {
		f()
		log.Info(fmt.Sprintf("run package:%s Init function ok ~", name))
	}

	return nil
}

// GetMysqlClient get mysqlClient
func GetMysqlClient() *mysql.Mysql {
	return mysqlClient
}

// GetRedisClient get redisClient
func GetRedisClient() *redis.ClusterClient {
	return redisClient
}

// GetMcClient get mcClient
func GetMcClient() *memcache.Client {
	return mcClient
}

// GetKafkaConf get KafkaConf
func GetKafkaConf() *config.KafkaConf {
	return kafkaConf
}
