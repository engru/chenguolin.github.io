// Package instance common function
// Created by chenguolin 2018-11-16
package instance

import (
	"github.com/chenguolin/go-api-service/config"
	"github.com/go-redis/redis"
)

// newRedisClient new redis client
func newRedisClient(conf *config.RedisConf) (*redis.ClusterClient, error) {
	// TODO (@cgl)
	return nil, nil
}
