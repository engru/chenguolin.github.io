// Package instance unit test
// Created by chenguolin 2018-11-16
package instance

import "testing"

func Test_newMysqlClient(t *testing.T) {
	// TODO (@cgl)
}
