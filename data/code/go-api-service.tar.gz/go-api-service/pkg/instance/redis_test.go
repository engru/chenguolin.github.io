// Package instance unit test
// Created by chenguolin 2018-11-16
package instance

import (
	"testing"
)

func Test_newRedisClient(t *testing.T) {
	// TODO (@cgl)
}
