// Package instance common function
// Created by chenguolin 2018-11-16
package instance

import (
	"github.com/bradfitz/gomemcache/memcache"
	"github.com/chenguolin/go-api-service/config"
)

// newMcClient new mc client
func newMcClient(conf *config.McConf) (*memcache.Client, error) {
	// TODO (@cgl)
	return nil, nil
}
