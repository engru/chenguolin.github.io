# API Service
[![CircleCI](https://circleci.com/gh/chenguolin/go-api-service.svg?style=svg)](https://circleci.com/gh/chenguolin/go-api-service)
[![Go Report Card](https://goreportcard.com/badge/github.com/chenguolin/go-api-service)](https://goreportcard.com/report/github.com/chenguolin/go-api-service)

使用`CircleCI`进程CI Pipeline校验，`Go Report Card`进行Golang项目代码分析
1. CircleCI: https://circleci.com/gh/chenguolin/go-api-service/tree/master
2. Go Report Card: https://goreportcard.com/report/github.com/chenguolin/go-api-service

用Gin实现的通用的Web Service框架, 提供HTTP API接口

API分成2个部分
1. 业务API
2. 开发运维api常用于版本检查、健康检查等

## 业务API
1. 查询用户信息: curl "http://localhost:8080/user/select.json?uid=111"
2. 创建新用户: curl "http://localhost:8080/user/create.json" -d "uid=111&name=cgl&phone=123456"
3. 更新用户信息: curl "http://localhost:8080/user/update.json" -d "uid=111&name=cgl2&phone=123456789
4. 删除用户: curl "http://localhost:8080/user/delete.json" -d "uid=111"

## 开发运维API
1. 服务状态检查: curl "http://localhost:9010/devops/health"
2. 服务性能分析
    * curl "http://localhost:9010/debug/pprof/allocs"
    * curl "http://localhost:9010/debug/pprof/block"
    * curl "http://localhost:9010/debug/pprof/cmdline"
    * curl "http://localhost:9010/debug/pprof/goroutine"
    * curl "http://localhost:9010/debug/pprof/heap"
    * curl "http://localhost:9010/debug/pprof/mutex"
    * curl "http://localhost:9010/debug/pprof/profile"
    * curl "http://localhost:9010/debug/pprof/threadcreate"
    * curl "http://localhost:9010/debug/pprof/trace"

# CI Workflow Check
1. `gocyclo`: 校验代码复杂度
2. `gofmt`: 校验代码是否都已经格式化
3. `golint`: 校验代码风格规范是否按照指定标准
4. `gosimple`: 校验代码是否可以简化
5. `govet`: 代码静态校验
6. `misspell`: 校验是否有英文单词拼写错误
7. `unused`: 校验是否有未使用变量、常量、函数、结构体等
8. `gotest`: 单元测试校验

# Gitlab CI
如果使用Gitlab，也可以通过`.gitlab-ci.yml`运行Gitlab CI Pipeline，详细介绍请参考下面2篇文章
1. [Gitlab 安装使用](https://chenguolin.github.io/2018/12/18/Git-Gitlab-%E5%AE%89%E8%A3%85%E4%BD%BF%E7%94%A8/)
2. [Gitlab CI和CD配置](https://chenguolin.github.io/2018/12/24/Git-Gitlab-CI%E5%92%8CCD%E9%85%8D%E7%BD%AE/)


