// Package crawltxs for crawl all etherscan.io transactions
// Created by chenguolin 2018-09-27
package crawltxs

import (
	"fmt"

	"github.com/antchfx/htmlquery"
	"github.com/chenguolin/go-log/log"
)

// CrawlAddressTxsHandle crawl ethereum address all tx
type CrawlAddressTxsHandle struct {
	// TODO (@cgl)
}

// NewCrawlAddressTxsHandle new CrawlAddressTxsHandle
func NewCrawlAddressTxsHandle() *CrawlAddressTxsHandle {
	return &CrawlAddressTxsHandle{}
}

// tx ethereum tx struct
type tx struct {
	TxHash string `json:"tx_hash"`
	From   string `json:"from"`
}

// DoProcess handler do process
func (h *CrawlAddressTxsHandle) DoProcess() {
	// 1. crawl all transactions
	txs, err := h.crawlTxs()
	if err != nil {
		log.Error("[DoProcess] crawlTxs error:", log.Err(err))
		return
	}

	// 2. print transaction
	for _, tx := range txs {
		log.Info("Etherscan Transactions", log.Object("tx", tx))
	}
}

// crawlTxs from etherscan.io
// https://etherscan.io/txs
func (h *CrawlAddressTxsHandle) crawlTxs() ([]*tx, error) {
	// 1. crawl html page
	txs := make([]*tx, 0)
	url := fmt.Sprintf("https://etherscan.io/txs")
	pageDoc, err := htmlquery.LoadURL(url)
	if err != nil {
		return txs, err
	}
	if pageDoc == nil {
		return txs, nil
	}

	// 2. parse dom tree
	expr := `//div[@class="table-responsive mb-2 mb-md-0"]/table/tbody/tr`
	txItems := htmlquery.Find(pageDoc, expr)
	if len(txItems) == 0 {
		log.Warn("[crawlTxs] CrawlAddressTxsHandle pageDoc not found any tx",
			log.String("URL", url))
		return txs, nil
	}

	for _, item := range txItems {
		// extract txhash
		text := htmlquery.Find(item, `/td[1]/span/a/text()`)
		if len(text) <= 0 {
			continue
		}
		txHash := text[0].Data

		// extract from
		text = htmlquery.Find(item, `/td[4]/span/a/text()`)
		if len(text) <= 0 {
			continue
		}
		from := text[0].Data

		// new tx
		newTx := &tx{
			TxHash: txHash,
			From:   from,
		}
		txs = append(txs, newTx)
	}

	return txs, nil
}
