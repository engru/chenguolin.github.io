// Package config for load toml file
// Created by chenguolin 2018-11-16
package config

import (
	"os"

	"github.com/BurntSushi/toml"
)

// global conf
var conf *Config

// loadFrom load config file
func loadFrom(filePath string) (*Config, error) {
	_, err := os.Stat(filePath)
	if err != nil {
		return nil, err
	}

	cfg := &Config{}
	_, err = toml.DecodeFile(filePath, cfg)
	if err != nil {
		return nil, err
	}

	return cfg, nil
}

// GetConfig get Config
func GetConfig(filePath string) (*Config, error) {
	if conf != nil {
		return conf, nil
	}

	cfg, err := loadFrom(filePath)
	if err != nil {
		return nil, err
	}

	conf = cfg
	return conf, nil
}

// SetConfig set config
func SetConfig(cfg *Config) {
	conf = cfg
}

// GetMysqlConf get MysqlConf
func GetMysqlConf() *MysqlConf {
	if conf == nil {
		return nil
	}

	return conf.Mysql
}

// GetKafkaConf get KafkaConf
func GetKafkaConf() *KafkaConf {
	if conf == nil {
		return nil
	}

	return conf.Kafka
}
