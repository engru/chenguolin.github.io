// Package config types define
// Created by chenguolin 2018-11-16
package config

// Config struct define
type Config struct {
	Mysql *MysqlConf `toml:"mysql"` //mysql配置
	Kafka *KafkaConf `toml:"kafka"` //kafka配置
}

// MysqlConf mysql config
type MysqlConf struct {
	Master           string   `toml:"master"`
	Slaves           []string `toml:"slaves"`
	Port             int      `toml:"port"`
	Username         string   `toml:"username"`
	Password         string   `toml:"password"`
	Dbname           string   `toml:"dbname"`
	MaxOpenConnCount int      `toml:"max_open_conn_count"`
	MaxIdleConnCount int      `toml:"max_idle_conn_count"`
	ConnWaitTimeMs   int      `toml:"conn_wait_time_ms"`
	ConnIdleTimeMs   int      `toml:"conn_idle_time_ms"`
	ConnTimeoutMs    int      `toml:"conn_timeout_ms"`
	WriteTimeoutMs   int      `toml:"write_timeout_ms"`
	ReadTimeoutMs    int      `toml:"read_timeout_ms"`
}

// KafkaConf kafka config
type KafkaConf struct {
	Brokers         string `toml:"brokers"`
	Topic           string `toml:"topic"`
	ConsumerGroupID string `toml:"consumer_group_id"`
}
