// Package main go crontab
// Created by chenguolin 2018-11-17
package main

import (
	"fmt"
	"os"
	"os/signal"
	"runtime/debug"
	"syscall"
	"time"

	"github.com/chenguolin/go-cron/config"
	"github.com/chenguolin/go-cron/cron"
	"github.com/chenguolin/go-cron/pkg/crawltxs"
	"github.com/chenguolin/go-log/log"
)

// main entry
func main() {
	log.Info("Start Cron ...")

	// 1. get ENV CLUSTER_STAGE value
	clusterStage := os.Getenv("CLUSTER_STAGE")
	if clusterStage == "" {
		panic("os.Getenv get CLUSTER_STAGE value is empty")
	}

	// 2. load config file
	configFile := fmt.Sprintf("./%s-config.toml", clusterStage)
	conf, err := config.GetConfig(configFile)
	if err != nil {
		panic("config.GetConfig error: " + err.Error())
	}
	// TODO unused conf
	fmt.Println(conf)

	// 3. start cron
	c := cron.NewCron()

	// add all handle
	c.AddHandle(cron.NewScheduler(cron.WithSecond(5), time.Now()),
		crawltxs.NewCrawlAddressTxsHandle())
	// TODO (@cgl) add other handle
	// c.AddHandle(cron.NewScheduler(cron.WithSecond(5), time.Now()),
	// 	crawltxs.NewCrawlAddressTxsHandle())
	//
	// c.AddHandle(cron.NewScheduler(cron.WithSecond(5), time.Now()),
	// 	crawltxs.NewCrawlAddressTxsHandle())
	//
	// c.AddHandle(cron.NewScheduler(cron.WithSecond(5), time.Now()),
	// 	crawltxs.NewCrawlAddressTxsHandle())

	c.Start()

	// 4. wait shutdown signal
	stopChan := make(chan struct{}, 1)
	registerSignal(stopChan)
	<-stopChan

	log.Info("Shutdown Cron ~")
}

// registerSignal register kill signal
func registerSignal(shutdown chan struct{}) {
	c := make(chan os.Signal)
	signal.Notify(c, os.Interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		defer func() {
			if err := recover(); err != nil {
				log.Error("[registerSignal] panic error: ",
					log.Object("error", err))
				debug.PrintStack()
			}
		}()

		for sig := range c {
			// close shutdown channel
			close(shutdown)
			log.Info("[registerSignal] receive system signal:" +
				sig.String() + ", going to shutdown ...")
			return
		}
	}()
}
