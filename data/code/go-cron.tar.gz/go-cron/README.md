# Cron
[![CircleCI](https://circleci.com/gh/chenguolin/go-cron.svg?style=svg)](https://circleci.com/gh/chenguolin/go-cron)
[![Go Report Card](https://goreportcard.com/badge/github.com/chenguolin/go-cron)](https://goreportcard.com/report/github.com/chenguolin/go-cron)

使用`CircleCI`进程CI Pipeline校验，`Go Report Card`进行Golang项目代码分析
1. CircleCI: https://circleci.com/gh/chenguolin/go-cron/tree/master
2. Go Report Card: https://goreportcard.com/report/github.com/chenguolin/go-cron

定时任务模块，如果有新的业务逻辑只需要在handler目录下新增一个go文件, 同时在main函数里面AddFunc新增一行配置即可

# Sample
```
c := cron.NewCron()

// TODO add handle
c.AddHandle(cron.NewScheduler(cron.WithSecond(5), time.Now()), handle.GetCrawlAddressTxsHandle())

// run cron
c.Start()
fmt.Println("Start cron handler ...")

// shutdown
stopSignalChan := make(chan os.Signal, 1)
signal.Notify(stopSignalChan, os.Interrupt, os.Kill, syscall.SIGTERM, syscall.SIGINT)
sig := <-stopSignalChan
if sig != nil {
    fmt.Println("got system signal:" + sig.String() + ", going to shutdown crontab")
	// Stop the scheduler (does not stop any jobs already running).
	c.Stop()
}
fmt.Println("Stop cron handler ~")
```

# CI Workflow Check
1. `gocyclo`: 校验代码复杂度
2. `gofmt`: 校验代码是否都已经格式化
3. `golint`: 校验代码风格规范是否按照指定标准
4. `gosimple`: 校验代码是否可以简化
5. `govet`: 代码静态校验
6. `misspell`: 校验是否有英文单词拼写错误
7. `unused`: 校验是否有未使用变量、常量、函数、结构体等
8. `gotest`: 单元测试校验

# Gitlab CI
如果使用Gitlab，也可以通过`.gitlab-ci.yml`运行Gitlab CI Pipeline，详细介绍请参考下面2篇文章
1. [Gitlab 安装使用](https://chenguolin.github.io/2018/12/18/Git-Gitlab-%E5%AE%89%E8%A3%85%E4%BD%BF%E7%94%A8/)
2. [Gitlab CI和CD配置](https://chenguolin.github.io/2018/12/24/Git-Gitlab-CI%E5%92%8CCD%E9%85%8D%E7%BD%AE/)
